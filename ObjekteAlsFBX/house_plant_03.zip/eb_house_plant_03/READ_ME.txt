NOT FOR COMMERCIAL USE

*   *   *   *   *

House Plant 03
eb_house_plant_03

House Plant 03 made to be used within Unreal. Materials PBR compliant. Great for use in a game or architectural render. For more details or questions feel free to contact me. 

DETAILS:
- Tri Count: 945
- Color Map: eb_house_plant_03_c
- Roughness Map: Packed in RED channel of eb_house_plant_03_g
- Metal Map: Packed in GREEN channel of eb_house_plant_03_g
- Opacity Mask: Packed in BLUE channel of eb_house_plant_03_g
- Normal Map: eb_house_plant_03_n

*   *   *   *   *

For questions contact Ernesto at ernestbezera@gmail.com